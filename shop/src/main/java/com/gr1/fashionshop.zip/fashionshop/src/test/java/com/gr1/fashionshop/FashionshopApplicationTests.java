package com.gr1.fashionshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FashionshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
